public class HW_1_Car {
    public String make;
    public String manufacturer;
    public boolean handicapAccess;

    public HW_1_Car(String make, String manufacturer, boolean handicapAccess){
        this.make = make;
        this.manufacturer = manufacturer;
        this.handicapAccess = handicapAccess;
    }
    


}
