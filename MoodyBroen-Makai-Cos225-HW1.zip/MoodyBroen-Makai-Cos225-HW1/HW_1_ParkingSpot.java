public class HW_1_ParkingSpot {
    public HW_1_Car parkedCar;
    public boolean handicap;

    public HW_1_ParkingSpot (boolean handicap){
        this.handicap = handicap;
    }

}
